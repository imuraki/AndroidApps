package com.example.homework1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private EditText weightInput;
    private EditText feetInput;
    private EditText inchesInput;
    private Button calculateBMI;
    private TextView bmiOutput;
    private TextView bmiMessage;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        weightInput = findViewById(R.id.weightInput);
        feetInput = findViewById(R.id.feetInput);
        inchesInput = findViewById(R.id.inchesInput);
        calculateBMI = findViewById(R.id.calculateBMI);
        bmiOutput = findViewById(R.id.bmiOutput);
        bmiMessage = findViewById(R.id.bmiMessage);
        calculateBMI.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View view) {
                if(weightInput.getText().toString().matches("") || feetInput.getText().toString().matches("")){
                    Toast.makeText(view.getContext(),"Invalid Input",Toast.LENGTH_LONG).show();
                    bmiOutput.setText("");
                    bmiMessage.setText("");
                }
               else if(Float.parseFloat(weightInput.getText().toString())<=1 || Float.parseFloat(feetInput.getText().toString())<1 ||
                        Float.parseFloat(weightInput.getText().toString())>2000 || Float.parseFloat(feetInput.getText().toString())>13){
                    Toast.makeText(view.getContext(),"Invalid Input",Toast.LENGTH_LONG).show();
                    bmiOutput.setText("");
                    bmiMessage.setText("");
                }
                else{
                    if(inchesInput.getText().toString().matches("") && weightInput.getText().toString() != null && feetInput.getText().toString() != null){
                        inchesInput.setText("0");
                    }
                    Float height = Float.parseFloat(feetInput.getText().toString())*12 + Float.parseFloat(inchesInput.getText().toString());
                    Float bmi =  (Float.parseFloat(weightInput.getText().toString()) / (height * height)) * 703;
                    bmiOutput.setText(String.format("Your BMI: %.2f" ,bmi));
                    if (bmi <= 18.5){
                        bmiMessage.setText("Your BMI Status: Underweight");
                    }
                    else if (bmi <= 24.9){
                        bmiMessage.setText("Your BMI Status: Normal weight");
                    }
                    else if (bmi <= 29.9){
                        bmiMessage.setText("Your BMI Status: Overweight");
                    }
                    else{
                        bmiMessage.setText("Your BMI Status : Obese");
                    }
                }

            }
        });


    }
}
